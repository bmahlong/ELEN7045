package za.ac.wits.dodge.sprites;

import javax.swing.ImageIcon;

import za.ac.dodge.sprites.AbstractSprite;

public class DodgePlayer extends AbstractSprite {

	public DodgePlayer(ImageIcon img, int x, int y) {
		super(img, x, y);
	}

}
