package za.ac.wits.dodge.utils;

public enum GameState {
	INITIALISED,
	PLAYING,
	PAUSED,
	STOPPED;
}
