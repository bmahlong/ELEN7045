To run the dodge game

1. Ensure you have Java 7 installed on your machine
2. Navigate to the executable folder
3. Run the command: java -jar dodge.jar

